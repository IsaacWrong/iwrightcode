# iWrightCode — Monochrome Brand Assets

Clean, single-color system. Four values, no accents, nothing competing.

## Color palette (the entire system)

```
#0D1117   dark surface / primary text on light
#E6EDF3   light surface / primary text on dark
#7D8590   secondary text (both modes)
#30363D   dark-mode borders
#D0D7DE   light-mode borders
```

On light (invoices, print): text is `#0D1117`, muted is `#57606A`, rules are `#D0D7DE` or `#0D1117` depending on weight.

On dark (web, social): text is `#E6EDF3`, muted is `#7D8590`, rules are `#30363D`.

## Typography

- **All wordmarks and UI:** JetBrains Mono, weight 500, letter-spacing -0.5 to -1
- **Body text:** Inter, weight 400
- Lowercase throughout — brand reads as `iwrightcode_` always, never capitalized

## The wordmark

`iwrightcode_` — lowercase, monospace, trailing underscore as cursor. The underscore is a static character (not animated) for all print, static image, and social contexts. On the website only, it becomes a blinking cursor via CSS animation.

## File index

### Core marks
- `wordmark-dark.svg` — primary wordmark on `#0D1117`
- `wordmark-light.svg` — primary wordmark on `#FFFFFF`
- `monogram-dark.svg` — `iw_` compressed form, 512×512, for square contexts
- `favicon.svg` — `iw_` at 32×32, for browser tab

### Commerce
- `stripe-invoice-header.svg` — 1200×180 horizontal strip for invoice top
- `stripe-brand-icon.svg` — 512×512 square for Stripe account icon
- `invoice-full-mockup.svg` — complete invoice mockup for reference / reproduction in a template
- `business-card.svg` — front + back on one canvas

### Social
- `x-header-banner.svg` — 1500×500
- `linkedin-banner.svg` — 1584×396
- `social-post-square.svg` — 1080×1080 quote template

### Email
- `email-signature.html` — table-based signature for Gmail/Apple Mail/Outlook

## Converting to PNG

Most platforms (Stripe, X, LinkedIn) need PNG. Options:

- **CloudConvert** (cloudconvert.com/svg-to-png) — free, no signup, pick exact pixel dimensions
- **Figma** — paste SVG, export at 1x/2x/3x
- **Command line:** `rsvg-convert -h 512 file.svg > file.png` (install: `brew install librsvg`)

## Quick-ship checklist

### Stripe (priority)
1. Convert `stripe-brand-icon.svg` → PNG 512×512 → upload as "Icon" in Stripe Dashboard → Settings → Branding
2. Convert `stripe-invoice-header.svg` → PNG 1200×180 → upload as "Logo"
3. Set brand color: `#0D1117`. Set accent: `#E6EDF3`.

### Social
1. Convert `x-header-banner.svg` → PNG 1500×500 → X profile header
2. Convert `monogram-dark.svg` → PNG 400×400 → X avatar
3. Convert `linkedin-banner.svg` → PNG 1584×396 → LinkedIn background
4. Same `monogram-dark.svg` PNG works for LinkedIn avatar

### Email
- Copy the contents of `email-signature.html` and paste as HTML into Gmail/Outlook signature settings. For Gmail, you may need to use a tool like htmlsig.com or paste via devtools "Edit as HTML" since Gmail's signature editor strips some formatting.

### Website
- Drop `favicon.svg` at `public/favicon.svg` in your Next.js app
- Use `wordmark-dark.svg` as your OG card base or build a dynamic one with the wordmark + a per-page title

## What makes this work

One color = no branding decisions per asset. Every new thing you make just picks dark bg or light bg, slaps the wordmark on it, and ships. The underscore carries all the personality so nothing else needs to.
